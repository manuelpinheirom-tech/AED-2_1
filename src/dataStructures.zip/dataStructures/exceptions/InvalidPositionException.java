package dataStructures.exceptions;

import java.io.Serial;

public class InvalidPositionException extends RuntimeException{
    @Serial
    private static final long serialVersionUID = 1L;
}

